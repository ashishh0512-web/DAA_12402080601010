"""Pattern-based recurrence complexity analyzer for common DAA recurrences.

Supports divide-and-conquer recurrences with equal or unequal integer divisors,
constant-decrement recurrences, polynomial/polylogarithmic tolls, sums of toll
terms, and simple exponential tolls. This is an educational asymptotic analyzer,
not a universal symbolic theorem prover.
"""
import math
import re


def _clean(s):
    s = str(s).lower().strip()
    for a, b in [("×", "*"), ("−", "-"), ("–", "-"), ("÷", "/"), ("²", "^2"), ("³", "^3")]:
        s = s.replace(a, b)
    s = re.sub(r"\s+", "", s)
    s = s.replace("log_2(n)", "log(n)").replace("log2(n)", "log(n)")
    s = s.replace("log(n)", "logn").replace("ln(n)", "logn")
    s = s.replace("log_2n", "logn")
    return s


def _fmt(x):
    if abs(x - round(x)) < 1e-8:
        return str(int(round(x)))
    return f"{x:.3g}"


def _complexity(n_power, log_power=0):
    if n_power < 1e-8:
        if log_power < 1e-8:
            return "O(1)"
        return "O(log n)" if abs(log_power - 1) < 1e-8 else f"O((log n)^{_fmt(log_power)})"
    n = "n" if abs(n_power - 1) < 1e-8 else f"n^{_fmt(n_power)}"
    if log_power < 1e-8:
        return f"O({n})"
    log = "log n" if abs(log_power - 1) < 1e-8 else f"(log n)^{_fmt(log_power)}"
    return f"O({n} {log})"


def _term_shape(term):
    """Return (n exponent, log exponent, exponential base) or None."""
    t = term.replace("*", "")
    t = t.strip("+")
    if not t or t in ("0",):
        return (float("-inf"), 0, None)
    if t in ("1", "c", "constant"):
        return (0, 0, None)
    exp = re.fullmatch(r"(\d+(?:\.\d+)?)\^n", t)
    if exp:
        return (float("inf"), 0, float(exp.group(1)))
    if t == "logn":
        return (0, 1, None)
    # Normalize nlogn, n^2logn, n^3(logn)^2, n^k*logn^q
    m = re.fullmatch(r"n(?:\^(\d+(?:\.\d+)?))?(?:logn(?:\^(\d+(?:\.\d+)?))?)?", t)
    if m:
        np = float(m.group(1) or 1)
        lp = float(m.group(2) or (1 if "logn" in t else 0))
        return (np, lp, None)
    # constant times n terms, e.g. 3n^2; constants don't affect Big-O
    m = re.fullmatch(r"\d+(?:\.\d+)?\*?n(?:\^(\d+(?:\.\d+)?))?(?:logn(?:\^(\d+(?:\.\d+)?))?)?", t)
    if m:
        np = float(m.group(1) or 1)
        lp = float(m.group(2) or (1 if "logn" in t else 0))
        return (np, lp, None)
    return None


def _work_terms(rhs, call_matches):
    chars = list(rhs)
    for m in call_matches:
        for i in range(m.start(), m.end()):
            chars[i] = " "
    rest = "".join(chars).replace("-", "+")
    rest = rest.replace("**", "^")
    terms = [x.strip() for x in rest.split("+") if x.strip()]
    if not terms:
        return [(float("-inf"), 0, None)], "0"
    shapes = []
    for term in terms:
        shape = _term_shape(term)
        if shape is None:
            return None, "".join(terms)
        shapes.append(shape)
    return shapes, "+".join(terms)


def solve_recurrence(raw):
    s = _clean(raw)
    if not s:
        return {"ok": False, "error": "Enter a recurrence relation."}
    if "=" in s:
        left, rhs = s.split("=", 1)
        if not re.fullmatch(r"[a-z]?t\(n\)", left):
            return {"ok": False, "error": "Use T(n)=... or enter only the right-hand side."}
    else:
        rhs = s
    # Calls: optional multiplier, T(n/b) or T(n-c); spaces already removed.
    pat = re.compile(r"(?<![a-z0-9_^])(?:(\d+)\*?)?t\(n(?:/(\d+(?:\.\d+)?)|-(\d+(?:\.\d+)?))\)")
    calls = list(pat.finditer(rhs))
    if not calls:
        return {"ok": False, "error": "No recursive call found. Example: T(n)=2T(n/2)+n or T(n)=T(n-1)+1."}
    parsed = []
    for m in calls:
        a = int(m.group(1) or 1)
        if a < 1:
            return {"ok": False, "error": "Recursive-call multipliers must be positive."}
        if m.group(2):
            b = float(m.group(2))
            if b <= 1:
                return {"ok": False, "error": "The divisor in T(n/b) must be greater than 1."}
            parsed.append((a, "divide", b))
        else:
            c = float(m.group(3))
            if c < 1:
                return {"ok": False, "error": "The decrement in T(n-c) must be at least 1."}
            parsed.append((a, "decrease", c))
    styles = {p[1] for p in parsed}
    if len(styles) != 1:
        return {"ok": False, "error": "This version does not estimate mixed T(n/b) and T(n-c) recurrences together. Try analyzing the dominant pattern separately."}
    shapes, work = _work_terms(rhs, calls)
    if shapes is None:
        return {"ok": False, "error": f"Recursive calls were found, but the non-recursive work '{work}' is not recognized. Try constants, n^k, log(n), n^k*log(n)^q, or c^n."}
    # The largest asymptotic toll term dominates.
    finite = [x for x in shapes if x[0] != float("-inf")]
    exp_terms = [x for x in finite if math.isinf(x[0])]
    if exp_terms:
        exp_base = max(x[2] for x in exp_terms)
        return {"ok": True, "complexity": f"O({_fmt(exp_base)}^n) (exponential toll)", "method": "Exponential-work dominance", "explanation": "The non-recursive exponential work dominates the polynomial/logarithmic work. This assumes the recurrence has the usual bounded recursive structure.", "details": {"work": work}}
    if finite:
        toll = max(finite, key=lambda x: (x[0], x[1]))
        k, q = toll[0], toll[1]
    else:
        k, q = float("-inf"), 0
    if styles == {"divide"}:
        # Akra-Bazzi exponent p solves sum(a_i / b_i^p) = 1, including unequal divisors.
        def fn(p): return sum(a / (b ** p) for a, _, b in parsed) - 1
        lo, hi = 0.0, 1.0
        while fn(hi) > 0 and hi < 100:
            hi *= 2
        for _ in range(160):
            mid = (lo + hi) / 2
            if fn(mid) > 0: lo = mid
            else: hi = mid
        p = (lo + hi) / 2
        # For toll n^k log^q, Akra-Bazzi integral gives p-case / toll-case.
        if k == float("-inf"):
            result, case = _complexity(p), "Akra–Bazzi / recursion-tree exponent"
            why = f"The recursive exponent p solves Σ(aᵢ/bᵢᵖ)=1; here p≈{p:.3f}. With no added work, the recursive structure determines the growth."
        elif abs(p-k) < 1e-7:
            result, case = _complexity(k, q+1), "Master Theorem / Akra–Bazzi — balanced case"
            why = f"The work f(n)=Θ(n^{_fmt(k)}(log n)^{_fmt(q)}) matches the recursive exponent p≈{p:.3f}, adding one logarithmic factor."
        elif p > k:
            result, case = _complexity(p), "Master Theorem / Akra–Bazzi — recursion dominates"
            why = f"The recursive exponent p≈{p:.3f} is larger than the polynomial toll exponent {k}; recursion dominates."
        else:
            result, case = _complexity(k, q), "Master Theorem / Akra–Bazzi — work dominates"
            why = f"The toll grows as Θ(n^{_fmt(k)}(log n)^{_fmt(q)}), faster than the recursive exponent p≈{p:.3f}; added work dominates (under standard regularity assumptions)."
        return {"ok": True, "complexity": result, "method": case, "explanation": why, "details": {"recursive_exponent": round(p, 4), "calls": len(parsed), "work": work}}
    # Constant decrement: one call sums the toll; multiple calls generally grow exponentially.
    if len(parsed) == 1 and parsed[0][0] == 1:
        if k == float("-inf"):
            result = "O(log n)" if parsed[0][2] == 1 else "O(n)"
        elif k == 0 and q == 0:
            result = "O(n)"
        else:
            result = _complexity(k + 1, q)
        return {"ok": True, "complexity": result, "method": "Repeated substitution / summation", "explanation": f"There are Θ(n) levels for a single T(n-c) call. Summing the recognized per-level work gives {result}.", "details": {"decrement": parsed[0][2], "work": work}}
    # Solve sum(a_i / r^c_i) = 1 for the characteristic growth factor.
    def fn(r): return sum(a / (r ** c) for a, _, c in parsed) - 1
    lo, hi = 1.0, 2.0
    while fn(hi) > 0 and hi < 1e12:
        hi *= 2
    for _ in range(160):
        mid = (lo + hi) / 2
        if fn(mid) > 0: lo = mid
        else: hi = mid
    root = (lo + hi) / 2
    result = f"O({_fmt(root)}^n)" if root > 1.000001 else _complexity(max(1, k+1), q)
    return {"ok": True, "complexity": result, "method": "Characteristic growth / recursion-tree estimate", "explanation": f"For multiple constant-decrement calls, the estimated growth factor r solves Σ(aᵢ/rᶜⁱ)=1; r≈{root:.4f}. This is an asymptotic estimate, not an exact closed-form solution.", "details": {"growth_factor": round(root, 4), "work": work}}
