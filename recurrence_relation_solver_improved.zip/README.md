# Recurrence Relation Solver — Improved Version

A Flask web app for analyzing common DAA recurrence relations.

## Run on Windows / VS Code
1. Extract the ZIP and open the folder in VS Code.
2. Open Terminal → New Terminal.
3. Run `py -m venv .venv`
4. Activate it: `.venv\Scripts\activate`
5. Install: `py -m pip install -r requirements.txt`
6. Start: `py app.py`
7. Open `http://127.0.0.1:5000` in your browser. Keep the terminal open.

## Run on macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 app.py
```
Open `http://127.0.0.1:5000`.

## Example relations
| Relation | Expected result |
|---|---|
| `T(n)=2T(n/2)+n` | `O(n log n)` |
| `T(n)=T(n/2)+log(n)` | `O((log n)^2)` |
| `T(n)=4T(n/2)+n^2` | `O(n^2 log n)` |
| `T(n)=T(n/2)+T(n/3)+n` | `O(n)` |
| `T(n)=T(n/2)+T(n/4)+1` | `O(n^0.694)` approximately |
| `T(n)=2T(n/3)+n+log(n)` | `O(n)` |
| `T(n)=T(n/3)+n^2+n` | `O(n^2)` |
| `T(n)=T(n-1)+n` | `O(n^2)` |
| `T(n)=T(n-1)+n^2` | `O(n^3)` |
| `T(n)=T(n-1)+2^n` | `O(2^n)` |
| `T(n)=T(n-1)+T(n-2)+1` | `O(1.62^n)` growth estimate |
| `T(n)=T(n-1)+T(n-3)` | `O(1.47^n)` growth estimate |
| `T(n)=3T(n/2)+n^2+n` | `O(n^2)` |
| `T(n)=T(n/2)+n^2*log(n)^3` | `O(n^2 (log n)^3)` |

You can enter the complete equation or only its right-hand side. Common spaces and spellings such as `log(n)`, `logn`, `ln(n)`, `×`, and `−` are normalized.

## What it supports
- Divide-and-conquer recurrences with multiple recursive calls and equal or unequal divisors, using a Master-Theorem/Akra–Bazzi-style exponent analysis.
- Constant-decrement recurrences such as `T(n-1)+n^k`, and multiple calls such as `T(n-1)+T(n-2)+1` using a characteristic-growth estimate.
- Constants, `log(n)`, `n^k`, `n^k*log(n)^q`, sums of work terms, and simple exponential work such as `2^n`.

## Limitations
This is a pattern-based educational analyzer, not a universal symbolic solver. It does not guarantee exact answers for every possible recurrence. Mixed forms containing both `T(n/b)` and `T(n-c)` are intentionally reported as unsupported. Floors/ceilings, variable coefficients, products of recursive calls, unusual functions, or unusual boundary conditions may need manual analysis. Characteristic-growth outputs and non-equal-divisor estimates are estimates; verify important answers using the relevant DAA theorem.
