const input = document.getElementById("recurrence");
const solveBtn = document.getElementById("solveBtn");
const resultEmpty = document.getElementById("resultEmpty");
const resultContent = document.getElementById("resultContent");
const errorBox = document.getElementById("errorBox");
const complexity = document.getElementById("complexity");
const method = document.getElementById("method");
const explanation = document.getElementById("explanation");
const details = document.getElementById("details");

document.querySelectorAll(".chip").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.value;
    document.querySelectorAll(".chip").forEach(chip => chip.classList.remove("active"));
    button.classList.add("active");
    runSolve();
  });
});

input.addEventListener("keydown", event => {
  if (event.key === "Enter") runSolve();
});

solveBtn.addEventListener("click", runSolve);

async function runSolve() {
  const recurrence = input.value.trim();
  if (!recurrence) {
    showError("Please enter a recurrence relation first.");
    input.focus();
    return;
  }
  solveBtn.disabled = true;
  solveBtn.querySelector("span:first-child").textContent = "Solving…";
  errorBox.classList.add("hidden");
  try {
    const response = await fetch("/solve", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({recurrence})
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      showError(data.error || "Could not solve this recurrence.");
      return;
    }
    resultEmpty.classList.add("hidden");
    errorBox.classList.add("hidden");
    resultContent.classList.remove("hidden");
    complexity.textContent = data.complexity;
    method.textContent = data.method;
    explanation.textContent = data.explanation;
    details.textContent = data.details
      ? Object.entries(data.details).map(([key, value]) => `${key.replaceAll("_", " ")} = ${value}`).join(" · ")
      : "";
  } catch (error) {
    showError("Could not connect to the Python solver. Make sure the Flask server is running.");
  } finally {
    solveBtn.disabled = false;
    solveBtn.querySelector("span:first-child").textContent = "Solve recurrence";
  }
}

function showError(message) {
  resultEmpty.classList.add("hidden");
  resultContent.classList.add("hidden");
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

// Populate a first result so the working model is clear immediately.
runSolve();
