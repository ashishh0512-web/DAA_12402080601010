from flask import Flask, render_template, request, jsonify
from recurrence_solver import solve_recurrence

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/solve", methods=["POST"])
def solve():
    payload = request.get_json(silent=True) or {}
    recurrence = str(payload.get("recurrence", "")).strip()
    if not recurrence:
        return jsonify({"ok": False, "error": "Please enter a recurrence relation."}), 400
    result = solve_recurrence(recurrence)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
